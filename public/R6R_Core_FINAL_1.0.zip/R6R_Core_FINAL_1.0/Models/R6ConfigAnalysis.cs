namespace R6R.Core.Models;

public sealed class R6SettingRow
{
    public string Key { get; set; } = "";
    public string Value { get; set; } = "";
    public string Category { get; set; } = "Other";
}

public sealed class R6Recommendation
{
    public string Severity { get; set; } = "INFO";
    public string Category { get; set; } = "General";
    public string Setting { get; set; } = "";
    public string Current { get; set; } = "";
    public string Recommended { get; set; } = "";
    public string Why { get; set; } = "";
}

public sealed class R6ConfigAnalysis
{
    public string ConfigPath { get; set; } = "";
    public DateTime AnalyzedAtUtc { get; set; }
    public List<R6SettingRow> Settings { get; set; } = new();
    public List<R6Recommendation> Recommendations { get; set; } = new();

    public int ReviewCount => Recommendations.Count(x => x.Severity == "REVIEW");
    public int InfoCount => Recommendations.Count(x => x.Severity == "INFO");
    public int PassCount => Recommendations.Count(x => x.Severity == "PASS");

    public int FpsCount => Recommendations.Count(x => x.Category == "FPS");
    public int LatencyCount => Recommendations.Count(x => x.Category == "Latency");
    public int VisibilityCount => Recommendations.Count(x => x.Category == "Visibility");
    public int DisplayCount => Recommendations.Count(x => x.Category == "Display");
    public int GraphicsCount => Recommendations.Count(x => x.Category == "Graphics");
    public int InputCount => Recommendations.Count(x => x.Category == "Input");

    public string OverallStatus =>
        ReviewCount >= 5 ? "TUNING ADVISED" :
        ReviewCount >= 1 ? "REVIEW RECOMMENDED" :
        "COMPETITIVE BASELINE";
}


public sealed class R6OptimizationChange
{
    public string Setting { get; set; } = "";
    public string Current { get; set; } = "";
    public string Proposed { get; set; } = "";
    public string Category { get; set; } = "";
    public string Why { get; set; } = "";
}
