namespace R6R.Core.Models;

public sealed class SystemInfo
{
    public DateTime ScannedAtUtc { get; set; }
    public string MachineName { get; set; } = "Unknown";
    public string OperatingSystem { get; set; } = "Unknown";
    public string WindowsEdition { get; set; } = "Unknown";
    public string Cpu { get; set; } = "Unknown";
    public string Gpu { get; set; } = "Unknown";
    public string Ram { get; set; } = "Unknown";
    public string Display { get; set; } = "Unknown";
    public string RefreshRate { get; set; } = "Unknown";
    public string Architecture { get; set; } = "Unknown";
    public string ProcessorCount { get; set; } = "Unknown";
    public string R6ConfigPath { get; set; } = "";
    public string R6ConfigStatus { get; set; } = "NOT DETECTED";
}
