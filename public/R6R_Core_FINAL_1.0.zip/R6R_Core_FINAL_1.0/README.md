# R6R Core 1.0 — Final Build

This is the consolidated final build based on the verified working 0.7.1 checkpoint.

## Included
- Guarded WPF startup with visible startup-error reporting
- Overview / Operator Console
- Windows system scan
- CPU / GPU / RAM / display detection
- Rainbow Six GameSettings.ini detection
- 158-setting config parser on the tested machine
- Analyzer+ competitive config review
- Config health score
- Manual config backup and protected restore
- Safe Optimizer preview
- Automatic pre-optimization backup
- Explicit confirmation before writes
- Temporary-file verification before commit
- Rollback to the last optimization backup
- JSON system report export
- NVReflexIndicator false-positive fix

## Safe Optimizer policy
The optimizer is deliberately conservative.

Writable allowlist:
- VSync / VerticalSync → 0
- RawInputMouseKeyboard / RawInput / RawMouse → 1
- NVReflex → 1 only when exact NVReflex is 0

It does not automatically change:
- FPSLimit
- FOV
- aspect ratio
- resolution
- render scale
- anti-aliasing
- texture / graphics quality tiers
- Windows registry
- Windows services
- drivers

The app does not claim guaranteed FPS gains.

## Run from source
```powershell
dotnet restore
dotnet build -c Release
dotnet run
```

## Recommended validation
1. Launch R6R Core.
2. Run SYSTEM SCAN.
3. Open R6 CONFIG and analyze the detected config.
4. Review Analyzer+ and the health score.
5. Open SAFE OPTIMIZER and build a preview.
6. Apply only after reviewing the proposed rows.
7. Use rollback if you want to restore the most recent pre-optimization state.
