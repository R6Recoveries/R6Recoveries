using System.IO;
using Microsoft.Win32;
using R6R.Core.Models;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

namespace R6R.Core.Services;

public static class SystemScanner
{
    public static SystemInfo Scan()
    {
        var info = new SystemInfo
        {
            ScannedAtUtc = DateTime.UtcNow,
            MachineName = Environment.MachineName,
            OperatingSystem = RuntimeInformation.OSDescription,
            WindowsEdition = GetWindowsEdition(),
            Cpu = GetCpuName(),
            Gpu = GetGpuName(),
            Ram = GetRam(),
            Architecture = RuntimeInformation.OSArchitecture.ToString(),
            ProcessorCount = Environment.ProcessorCount.ToString()
        };

        var display = GetPrimaryDisplay();
        info.Display = display.Resolution;
        info.RefreshRate = display.RefreshRate;

        var config = FindR6Config();
        info.R6ConfigPath = config ?? "";
        info.R6ConfigStatus = config is null ? "NOT DETECTED" : "DETECTED";
        return info;
    }

    public static string? FindR6Config()
    {
        var candidates = new List<string>();

        var docs = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        if (!string.IsNullOrWhiteSpace(docs))
            candidates.Add(Path.Combine(docs, "My Games", "Rainbow Six - Siege"));

        var user = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        if (!string.IsNullOrWhiteSpace(user))
        {
            candidates.Add(Path.Combine(user, "Documents", "My Games", "Rainbow Six - Siege"));
            candidates.Add(Path.Combine(user, "OneDrive", "Documents", "My Games", "Rainbow Six - Siege"));
        }

        foreach (var baseDir in candidates.Distinct(StringComparer.OrdinalIgnoreCase))
        {
            try
            {
                if (!Directory.Exists(baseDir)) continue;
                var match = Directory.EnumerateFiles(baseDir, "GameSettings.ini", SearchOption.AllDirectories)
                    .FirstOrDefault();
                if (match is not null) return match;
            }
            catch { }
        }

        return null;
    }

    private static string GetCpuName()
    {
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(@"HARDWARE\DESCRIPTION\System\CentralProcessor\0");
            return key?.GetValue("ProcessorNameString")?.ToString()?.Trim() ?? "Unknown";
        }
        catch { return "Unknown"; }
    }

    private static string GetWindowsEdition()
    {
        try
        {
            using var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion");
            var product = key?.GetValue("ProductName")?.ToString() ?? "Windows";
            var display = key?.GetValue("DisplayVersion")?.ToString() ?? "";
            var buildText = key?.GetValue("CurrentBuildNumber")?.ToString() ?? "";
            int.TryParse(buildText, out var build);

            // Windows 11 retained "Windows 10" in some underlying version strings.
            if (build >= 22000 && product.Contains("Windows 10", StringComparison.OrdinalIgnoreCase))
                product = product.Replace("Windows 10", "Windows 11", StringComparison.OrdinalIgnoreCase);

            return $"{product} {display} (Build {buildText})".Replace("  ", " ").Trim();
        }
        catch { return RuntimeInformation.OSDescription; }
    }

    private static string GetGpuName()
    {
        var output = RunPowerShell("Get-CimInstance Win32_VideoController | Select-Object -ExpandProperty Name");
        if (string.IsNullOrWhiteSpace(output)) return "Unknown";
        return string.Join(", ", output.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(x => x.Trim()).Distinct());
    }

    private static string GetRam()
    {
        try
        {
            var status = new MEMORYSTATUSEX();
            if (GlobalMemoryStatusEx(status))
                return $"{status.ullTotalPhys / 1024d / 1024d / 1024d:0.0} GB";
        }
        catch { }
        return "Unknown";
    }

    private static (string Resolution, string RefreshRate) GetPrimaryDisplay()
    {
        try
        {
            var dm = new DEVMODE();
            dm.dmSize = (short)Marshal.SizeOf<DEVMODE>();
            if (EnumDisplaySettings(null, ENUM_CURRENT_SETTINGS, ref dm))
                return ($"{dm.dmPelsWidth} x {dm.dmPelsHeight}", $"{dm.dmDisplayFrequency} Hz");
        }
        catch { }

        return ("Unknown", "Unknown");
    }

    private static string RunPowerShell(string command)
    {
        try
        {
            var psi = new ProcessStartInfo
            {
                FileName = "powershell.exe",
                Arguments = $"-NoProfile -ExecutionPolicy Bypass -Command \"{command}\"",
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true,
                StandardOutputEncoding = Encoding.UTF8
            };
            using var process = Process.Start(psi);
            if (process is null) return "";
            var result = process.StandardOutput.ReadToEnd();
            process.WaitForExit(5000);
            return result.Trim();
        }
        catch { return ""; }
    }

    private const int ENUM_CURRENT_SETTINGS = -1;

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern bool EnumDisplaySettings(string? deviceName, int modeNum, ref DEVMODE devMode);

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct DEVMODE
    {
        private const int CCHDEVICENAME = 32;
        private const int CCHFORMNAME = 32;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = CCHDEVICENAME)] public string dmDeviceName;
        public short dmSpecVersion, dmDriverVersion, dmSize, dmDriverExtra;
        public int dmFields, dmPositionX, dmPositionY, dmDisplayOrientation, dmDisplayFixedOutput;
        public short dmColor, dmDuplex, dmYResolution, dmTTOption, dmCollate;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = CCHFORMNAME)] public string dmFormName;
        public short dmLogPixels;
        public int dmBitsPerPel, dmPelsWidth, dmPelsHeight, dmDisplayFlags, dmDisplayFrequency;
        public int dmICMMethod, dmICMIntent, dmMediaType, dmDitherType, dmReserved1, dmReserved2, dmPanningWidth, dmPanningHeight;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    private sealed class MEMORYSTATUSEX
    {
        public uint dwLength = (uint)Marshal.SizeOf<MEMORYSTATUSEX>();
        public uint dwMemoryLoad;
        public ulong ullTotalPhys, ullAvailPhys, ullTotalPageFile, ullAvailPageFile, ullTotalVirtual, ullAvailVirtual, ullAvailExtendedVirtual;
    }

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GlobalMemoryStatusEx([In, Out] MEMORYSTATUSEX lpBuffer);
}
