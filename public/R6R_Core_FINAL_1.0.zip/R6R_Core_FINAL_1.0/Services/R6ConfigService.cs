using R6R.Core.Models;
using System.Globalization;
using System.IO;

namespace R6R.Core.Services;

public static class R6ConfigService
{
    public static string BackupRoot =>
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "R6R Core", "Backups");

    public static string CreateBackup(string configPath, string label = "backup")
    {
        if (!File.Exists(configPath))
            throw new FileNotFoundException("R6 GameSettings.ini was not found.", configPath);

        Directory.CreateDirectory(BackupRoot);
        var stamp = DateTime.Now.ToString("yyyyMMdd-HHmmss");
        var destination = Path.Combine(BackupRoot, $"GameSettings-{label}-{stamp}.ini");
        File.Copy(configPath, destination, false);
        return destination;
    }

    public static string? GetLatestBackup()
    {
        if (!Directory.Exists(BackupRoot)) return null;
        return Directory.EnumerateFiles(BackupRoot, "GameSettings-*.ini")
            .OrderByDescending(File.GetLastWriteTimeUtc)
            .FirstOrDefault();
    }

    public static string RestoreLatest(string configPath)
    {
        var latest = GetLatestBackup() ?? throw new InvalidOperationException("No R6R backup exists yet.");
        CreateBackup(configPath, "pre-restore");
        File.Copy(latest, configPath, true);
        return latest;
    }

    public static R6ConfigAnalysis Analyze(string configPath)
    {
        if (!File.Exists(configPath))
            throw new FileNotFoundException("R6 GameSettings.ini was not found.", configPath);

        var analysis = new R6ConfigAnalysis
        {
            ConfigPath = configPath,
            AnalyzedAtUtc = DateTime.UtcNow
        };

        string section = "General";

        foreach (var raw in File.ReadLines(configPath))
        {
            var line = raw.Trim();
            if (line.Length == 0 || line.StartsWith(";") || line.StartsWith("#")) continue;

            if (line.StartsWith("[") && line.EndsWith("]"))
            {
                section = line[1..^1].Trim();
                continue;
            }

            var equals = line.IndexOf('=');
            if (equals <= 0) continue;

            var key = line[..equals].Trim();
            var value = line[(equals + 1)..].Trim();

            analysis.Settings.Add(new R6SettingRow
            {
                Key = key,
                Value = value,
                Category = Classify(key, section)
            });
        }

        BuildAnalyzerPlusRecommendations(analysis);
        return analysis;
    }

    private static string Classify(string key, string section)
    {
        var k = key.ToLowerInvariant();
        var s = section.ToLowerInvariant();

        if (ContainsAny(k, "resolution", "refresh", "display", "window", "fullscreen", "vsync", "aspect", "monitor"))
            return "Display";
        if (ContainsAny(k, "quality", "texture", "shadow", "reflection", "ambient", "bloom", "lens", "depth",
            "anti", "anisotropic", "lod", "render", "terrain", "particle", "shading", "volumetric"))
            return "Graphics";
        if (ContainsAny(k, "fps", "frame", "latency", "reflex"))
            return "Performance";
        if (ContainsAny(k, "mouse", "sensitivity", "input", "rawinput"))
            return "Input";
        if (ContainsAny(k, "fov", "fieldofview"))
            return "Visibility";

        if (s.Contains("display")) return "Display";
        if (s.Contains("graphics")) return "Graphics";
        if (s.Contains("input")) return "Input";
        return "Other";
    }

    private static void BuildAnalyzerPlusRecommendations(R6ConfigAnalysis analysis)
    {
        foreach (var row in analysis.Settings)
        {
            var key = row.Key.ToLowerInvariant();
            var value = row.Value.Trim();

            if (ContainsAny(key, "fpslimit", "frameratelimit", "fpscap", "framecap"))
            {
                if (TryInt(value, out var cap))
                {
                    if (cap == 0)
                        Add(analysis, "PASS", "FPS", row, "0 / uncapped",
                            "The config appears uncapped, so the game is not being limited below your detected 240 Hz display by this setting.");
                    else if (cap < 240)
                        Add(analysis, "REVIEW", "FPS", row, "240+ FPS if stable, or a deliberate stable cap",
                            "Your display scan detected 240 Hz. A lower in-game cap can limit frame delivery below the display refresh rate.");
                    else
                        Add(analysis, "PASS", "FPS", row, value,
                            "The configured frame cap is not below the detected 240 Hz refresh target.");
                }
                continue;
            }

            if (!key.Contains("indicator") &&
                ContainsAny(key, "nvreflex", "nvidiareflex", "reflexmode"))
            {
                if (TryInt(value, out var reflex))
                {
                    if (reflex == 0)
                        Add(analysis, "REVIEW", "Latency", row, "1 or 2 where supported",
                            "NVIDIA Reflex appears disabled. On supported NVIDIA hardware, enabling Reflex can reduce render-queue latency.");
                    else if (reflex == 1)
                        Add(analysis, "PASS", "Latency", row, "1",
                            "NVIDIA Reflex appears enabled.");
                    else if (reflex == 2)
                        Add(analysis, "PASS", "Latency", row, "2",
                            "NVIDIA Reflex appears enabled in the more aggressive low-latency mode.");
                    else
                        Add(analysis, "INFO", "Latency", row, "Verify in-game Reflex mode",
                            "Core found a Reflex-related value it does not fully map yet.");
                }
                continue;
            }

            if (ContainsAny(key, "vsync", "verticalsync"))
            {
                if (IsEnabled(value) || (TryInt(value, out var syncMode) && syncMode > 0))
                    Add(analysis, "REVIEW", "Latency", row, "Off / 0 for a latency-focused setup",
                        "V-Sync can add synchronization latency, though disabling it may introduce tearing.");
                else
                    Add(analysis, "PASS", "Latency", row, "0",
                        "V-Sync appears disabled, matching a latency-focused competitive baseline.");
                continue;
            }

            if (ContainsAny(key, "rawinput", "raw_mouse", "rawmouse"))
            {
                if (IsEnabled(value))
                    Add(analysis, "PASS", "Input", row, "1", "Raw input appears enabled.");
                else
                    Add(analysis, "REVIEW", "Input", row, "On / 1",
                        "Raw mouse input can avoid extra pointer processing where supported.");
                continue;
            }

            if (ContainsAny(key, "refreshrate", "refresh"))
            {
                if (TryDouble(value, out var hz) && hz > 0)
                {
                    if (hz < 239)
                        Add(analysis, "REVIEW", "Display", row, "240 Hz",
                            "Core detected a 240 Hz desktop display while this config value is lower.");
                    else
                        Add(analysis, "PASS", "Display", row, "240 Hz",
                            "The config refresh value is consistent with your detected high-refresh display.");
                }
                continue;
            }

            if (ContainsAny(key, "windowmode", "displaymode", "fullscreen"))
            {
                Add(analysis, "INFO", "Display", row,
                    "Prefer the lowest-latency fullscreen mode available",
                    "Fullscreen behavior varies by game version and Windows presentation mode, so Core reports the current mode without assuming a universal numeric mapping.");
                continue;
            }

            if (ContainsAny(key, "renderscale", "resolutionscale", "renderresolution"))
            {
                if (TryDouble(value, out var scale))
                {
                    if (scale < 75)
                        Add(analysis, "INFO", "Visibility", row, "75-100% depending on performance target",
                            "A very low render scale can improve performance but materially reduce target clarity.");
                    else if (scale > 100)
                        Add(analysis, "REVIEW", "FPS", row, "100% unless supersampling is intentional",
                            "Rendering above native scale increases GPU workload.");
                    else
                        Add(analysis, "PASS", "Visibility", row, value,
                            "Render scale is within a common clarity/performance balance range.");
                }
                continue;
            }

            if (ContainsAny(key, "motionblur", "motion_blur", "bloom", "depthoffield", "dof", "lensflare", "chromatic"))
            {
                if (IsEnabled(value))
                    Add(analysis, "REVIEW", "Visibility", row, "Off / 0",
                        "This effect can reduce competitive visual clarity or add unnecessary visual processing.");
                else
                    Add(analysis, "PASS", "Visibility", row, value,
                        "This visual effect appears disabled.");
                continue;
            }

            if (ContainsAny(key, "antialiasing", "anti_aliasing", "aaquality"))
            {
                Add(analysis, "INFO", "Visibility", row,
                    "Use the clearest mode that preserves stable performance",
                    "Anti-aliasing is a clarity/performance tradeoff, so Core does not prescribe one value without frame-time testing.");
                continue;
            }

            if (ContainsAny(key, "texturequality", "texture_quality"))
            {
                if (TryInt(value, out var textureLevel))
                {
                    if (textureLevel >= 3)
                        Add(analysis, "INFO", "Graphics", row,
                            "Review one tier lower if VRAM or frame-time pressure appears",
                            "High texture quality can increase memory pressure, but it is not automatically bad on modern GPUs.");
                    else
                        Add(analysis, "PASS", "Graphics", row, value,
                            "Texture quality is not obviously excessive from this config value alone.");
                }
                continue;
            }

            if (ContainsAny(key, "shadow", "reflection", "ambientocclusion", "ssao", "shading", "terrain", "particle", "volumetric"))
            {
                if (TryInt(value, out var level))
                {
                    if (level >= 3)
                        Add(analysis, "INFO", "Graphics", row, "Review a lower competitive tier",
                            "This graphics setting appears relatively high and may add GPU load.");
                    else
                        Add(analysis, "PASS", "Graphics", row, value,
                            "This graphics tier is not obviously high from the config value alone.");
                }
                continue;
            }

            if (ContainsAny(key, "anisotropic"))
            {
                Add(analysis, "INFO", "Graphics", row,
                    "Keep unless testing shows a meaningful cost",
                    "Anisotropic filtering often has modest performance cost on modern GPUs, so Core does not recommend lowering it automatically.");
                continue;
            }

            if (ContainsAny(key, "fieldofview", "fov"))
            {
                Add(analysis, "INFO", "Visibility", row, "Personal competitive preference",
                    "Wider FOV improves peripheral awareness but can make distant targets appear smaller, so there is no single safe automatic recommendation.");
                continue;
            }

            if (ContainsAny(key, "aspectratio", "aspect"))
            {
                Add(analysis, "INFO", "Visibility", row, "Personal competitive preference",
                    "Aspect ratio changes horizontal visibility, target shape, and perceived motion. Core does not treat one ratio as universally best.");
                continue;
            }

            if (ContainsAny(key, "resolutionwidth", "resolutionheight"))
            {
                Add(analysis, "INFO", "Display", row, "Match the intended competitive resolution",
                    "Resolution is a deliberate clarity/FPS tradeoff and should not be changed automatically.");
                continue;
            }
        }

        analysis.Recommendations = analysis.Recommendations
            .GroupBy(x => $"{x.Category}|{x.Setting}|{x.Current}|{x.Recommended}|{x.Severity}", StringComparer.OrdinalIgnoreCase)
            .Select(g => g.First())
            .OrderBy(x => SeverityRank(x.Severity))
            .ThenBy(x => CategoryRank(x.Category))
            .ThenBy(x => x.Setting)
            .ToList();

        if (analysis.Recommendations.Count == 0)
        {
            analysis.Recommendations.Add(new R6Recommendation
            {
                Severity = "PASS",
                Category = "General",
                Setting = "GameSettings.ini",
                Current = "Parsed successfully",
                Recommended = "No automatic change",
                Why = "Core parsed the configuration but did not find a setting matching the conservative Analyzer+ rules."
            });
        }
    }

    private static void Add(R6ConfigAnalysis analysis, string severity, string category, R6SettingRow row, string recommended, string why)
    {
        analysis.Recommendations.Add(new R6Recommendation
        {
            Severity = severity,
            Category = category,
            Setting = row.Key,
            Current = row.Value,
            Recommended = recommended,
            Why = why
        });
    }

    private static int SeverityRank(string severity) => severity switch
    {
        "REVIEW" => 0,
        "INFO" => 1,
        "PASS" => 2,
        _ => 3
    };

    private static int CategoryRank(string category) => category switch
    {
        "FPS" => 0,
        "Latency" => 1,
        "Visibility" => 2,
        "Display" => 3,
        "Graphics" => 4,
        "Input" => 5,
        _ => 6
    };

    private static bool ContainsAny(string value, params string[] parts) =>
        parts.Any(part => value.Contains(part, StringComparison.OrdinalIgnoreCase));

    private static bool IsEnabled(string value) =>
        value.Equals("1") ||
        value.Equals("true", StringComparison.OrdinalIgnoreCase) ||
        value.Equals("yes", StringComparison.OrdinalIgnoreCase) ||
        value.Equals("on", StringComparison.OrdinalIgnoreCase) ||
        value.Equals("enabled", StringComparison.OrdinalIgnoreCase);

    private static bool TryInt(string value, out int result) =>
        int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out result);

    private static bool TryDouble(string value, out double result) =>
        double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out result);

    public static List<R6OptimizationChange> BuildSafeOptimizationPlan(string configPath)
    {
        var analysis = Analyze(configPath);
        var plan = new List<R6OptimizationChange>();

        foreach (var row in analysis.Settings)
        {
            var key = row.Key.Trim();
            var lower = key.ToLowerInvariant();
            var current = row.Value.Trim();

            // 0.6 only writes rules whose key/value semantics we have explicitly tested.
            // NVReflexIndicator is intentionally excluded.
            if ((lower == "vsync" || lower == "verticalsync") &&
                (IsEnabled(current) || (TryInt(current, out var sync) && sync > 0)))
            {
                AddPlan(plan, row, "0", "Latency",
                    "Disable V-Sync for the latency-focused preset. Tearing may increase.");
                continue;
            }

            if ((lower == "rawinputmousekeyboard" ||
                 lower == "rawinput" ||
                 lower == "rawmouse") &&
                !IsEnabled(current))
            {
                AddPlan(plan, row, "1", "Input",
                    "Enable raw input where supported to avoid extra pointer processing.");
                continue;
            }

            if (lower == "nvreflex" && TryInt(current, out var reflex) && reflex == 0)
            {
                AddPlan(plan, row, "1", "Latency",
                    "Enable NVIDIA Reflex on supported NVIDIA hardware.");
                continue;
            }

            // Intentionally no automatic FPSLimit, FOV, aspect ratio, resolution,
            // render scale, AA, texture, or graphics-quality edits in 0.6.
        }

        return plan;
    }

    public static string ApplySafeOptimizationPlan(
        string configPath,
        IReadOnlyList<R6OptimizationChange> plan)
    {
        if (!File.Exists(configPath))
            throw new FileNotFoundException("R6 GameSettings.ini was not found.", configPath);

        if (plan.Count == 0)
            throw new InvalidOperationException("There are no verified safe changes to apply.");

        // Mandatory automatic backup before touching the live file.
        var backup = CreateBackup(configPath, "pre-optimize");

        var lines = File.ReadAllLines(configPath).ToList();
        var remaining = plan.ToDictionary(
            x => x.Setting,
            x => x,
            StringComparer.OrdinalIgnoreCase);

        for (int i = 0; i < lines.Count; i++)
        {
            var trimmed = lines[i].Trim();
            if (trimmed.Length == 0 || trimmed.StartsWith(";") || trimmed.StartsWith("#"))
                continue;

            var equals = trimmed.IndexOf('=');
            if (equals <= 0) continue;

            var key = trimmed[..equals].Trim();

            if (!remaining.TryGetValue(key, out var change))
                continue;

            var leading = lines[i][..(lines[i].Length - lines[i].TrimStart().Length)];
            lines[i] = $"{leading}{key}={change.Proposed}";
            remaining.Remove(key);
        }

        if (remaining.Count > 0)
            throw new InvalidOperationException(
                "Core could not safely locate every proposed setting. No optimization was committed.");

        var temp = configPath + ".r6r.tmp";

        try
        {
            File.WriteAllLines(temp, lines);

            // Verify the temporary file before replacing the live config.
            var tempAnalysis = Analyze(temp);
            foreach (var change in plan)
            {
                var verified = tempAnalysis.Settings.Any(
                    x => x.Key.Equals(change.Setting, StringComparison.OrdinalIgnoreCase) &&
                         x.Value.Equals(change.Proposed, StringComparison.OrdinalIgnoreCase));

                if (!verified)
                    throw new InvalidOperationException(
                        $"Verification failed for {change.Setting}. No optimization was committed.");
            }

            File.Copy(temp, configPath, true);
        }
        finally
        {
            if (File.Exists(temp))
                File.Delete(temp);
        }

        return backup;
    }

    public static string RollbackLatestOptimization(string configPath)
    {
        if (!Directory.Exists(BackupRoot))
            throw new InvalidOperationException("No optimizer rollback backup exists.");

        var backup = Directory
            .EnumerateFiles(BackupRoot, "GameSettings-pre-optimize-*.ini")
            .OrderByDescending(File.GetLastWriteTimeUtc)
            .FirstOrDefault()
            ?? throw new InvalidOperationException("No optimizer rollback backup exists.");

        CreateBackup(configPath, "pre-rollback");
        File.Copy(backup, configPath, true);
        return backup;
    }

    private static void AddPlan(
        List<R6OptimizationChange> plan,
        R6SettingRow row,
        string proposed,
        string category,
        string why)
    {
        if (row.Value.Trim().Equals(proposed, StringComparison.OrdinalIgnoreCase))
            return;

        plan.Add(new R6OptimizationChange
        {
            Setting = row.Key,
            Current = row.Value,
            Proposed = proposed,
            Category = category,
            Why = why
        });
    }


    public static int CalculateHealthScore(string configPath)
    {
        var analysis = Analyze(configPath);

        // Conservative score: begin healthy, then subtract only for surfaced findings.
        // Review findings cost more than informational findings. PASS rows never inflate above 100.
        var score = 100;
        score -= analysis.Recommendations.Count(x =>
            x.Severity.Equals("REVIEW", StringComparison.OrdinalIgnoreCase)) * 12;
        score -= analysis.Recommendations.Count(x =>
            x.Severity.Equals("INFO", StringComparison.OrdinalIgnoreCase)) * 2;

        return Math.Clamp(score, 0, 100);
    }

    public static string HealthLabel(int score) =>
        score >= 90 ? "READY" :
        score >= 75 ? "GOOD" :
        score >= 60 ? "REVIEW" : "ATTENTION";

}
