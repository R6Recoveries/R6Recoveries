using System.IO;
using System.Windows;
using System.Windows.Threading;

namespace R6R.Core;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        DispatcherUnhandledException += OnDispatcherUnhandledException;

        try
        {
            var window = new MainWindow();
            MainWindow = window;
            window.Show();
        }
        catch (Exception ex)
        {
            ReportFatal("R6R Core failed during startup.", ex);
            Shutdown(-1);
        }
    }

    private void OnDispatcherUnhandledException(
        object sender,
        DispatcherUnhandledExceptionEventArgs e)
    {
        ReportFatal("R6R Core encountered an unhandled UI error.", e.Exception);
        e.Handled = true;
        Shutdown(-1);
    }

    private static void ReportFatal(string heading, Exception ex)
    {
        var details = $"{heading}{Environment.NewLine}{Environment.NewLine}{ex}";

        try
        {
            var logPath = Path.Combine(
                AppContext.BaseDirectory,
                "R6R-Core-startup-error.txt");

            File.WriteAllText(logPath, details);
        }
        catch
        {
            // Never hide the original startup error because log writing failed.
        }

        try
        {
            MessageBox.Show(
                details,
                "R6R Core Startup Error",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
        catch
        {
        }
    }
}
