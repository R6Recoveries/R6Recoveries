using Microsoft.Win32;
using R6R.Core.Models;
using R6R.Core.Services;
using System.Diagnostics;
using System.IO;
using System.Text.Json;
using System.Windows;

namespace R6R.Core;

public partial class MainWindow : Window
{
    private SystemInfo? _lastScan;
    private string? _configPath;
    private List<R6OptimizationChange> _optimizationPlan = new();

    public MainWindow()
    {
        InitializeComponent();
        RefreshOverviewFromConfig();
    }

    private void RunScan_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            ScanStatusText.Text = "Scanning system...";
            _lastScan = SystemScanner.Scan();
            _configPath = string.IsNullOrWhiteSpace(_lastScan.R6ConfigPath)
                ? null
                : _lastScan.R6ConfigPath;

            CpuText.Text = _lastScan.Cpu;
            GpuText.Text = _lastScan.Gpu;
            RamText.Text = _lastScan.Ram;
            DisplayText.Text = $"{_lastScan.Display} @ {_lastScan.RefreshRate}";
            WindowsText.Text = _lastScan.WindowsEdition;
            ArchitectureText.Text = _lastScan.Architecture;
            ProcessorText.Text = _lastScan.ProcessorCount;
            ConfigStatusText.Text = _lastScan.R6ConfigStatus;
            ConfigPathText.Text = _configPath ?? "R6 GameSettings.ini was not detected.";

            ScanStatusText.Text = $"Scan complete // {_lastScan.R6ConfigStatus}";
        }
        catch (Exception ex)
        {
            ScanStatusText.Text = $"Scan failed: {ex.Message}";
        }
        MarkOverviewSystemScanned();
    }

    private void ExportReport_Click(object sender, RoutedEventArgs e)
    {
        if (_lastScan is null)
        {
            MessageBox.Show("Run a system scan first.", "R6R Core");
            return;
        }

        var dialog = new SaveFileDialog
        {
            FileName = $"R6R-System-Report-{DateTime.Now:yyyyMMdd-HHmmss}.json",
            Filter = "JSON report (*.json)|*.json"
        };

        if (dialog.ShowDialog() == true)
        {
            File.WriteAllText(
                dialog.FileName,
                JsonSerializer.Serialize(
                    _lastScan,
                    new JsonSerializerOptions { WriteIndented = true }));

            ScanStatusText.Text = $"Report exported: {dialog.FileName}";
        }
    }

    private bool EnsureConfig()
    {
        _configPath ??= SystemScanner.FindR6Config();

        if (_configPath is null || !File.Exists(_configPath))
        {
            MessageBox.Show(
                "R6 GameSettings.ini could not be located. Run Rainbow Six Siege at least once, then run the system scan again.",
                "R6R Core");
            return false;
        }

        ConfigPathText.Text = _configPath;
        return true;
    }

    private void AnalyzeConfig_Click(object sender, RoutedEventArgs e)
    {
        if (!EnsureConfig()) return;

        try
        {
            var analysis = R6ConfigService.Analyze(_configPath!);

            SettingsGrid.ItemsSource = analysis.Settings;
            RecommendationsGrid.ItemsSource = analysis.Recommendations;

            OverallStatusText.Text = analysis.OverallStatus;
            ParsedCountText.Text = analysis.Settings.Count.ToString();
            ReviewCountText.Text = analysis.ReviewCount.ToString();
            InfoPassCountText.Text = $"{analysis.InfoCount} / {analysis.PassCount}";

            ConfigActionStatusText.Text =
                $"Analyzer+ complete // {analysis.Settings.Count} settings parsed // " +
                $"{analysis.ReviewCount} review // {analysis.InfoCount} info // {analysis.PassCount} pass. " +
                "No settings were changed.";
        }
        catch (Exception ex)
        {
            ConfigActionStatusText.Text = $"Analysis failed: {ex.Message}";
        }
        RefreshOverviewFromConfig();
    }

    private void BackupConfig_Click(object sender, RoutedEventArgs e)
    {
        if (!EnsureConfig()) return;

        try
        {
            var path = R6ConfigService.CreateBackup(_configPath!);
            ConfigActionStatusText.Text = $"Backup created: {path}";
            MessageBox.Show("R6 config backup created successfully.", "R6R Core");
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Backup failed");
        }
    }

    private void RestoreLatest_Click(object sender, RoutedEventArgs e)
    {
        if (!EnsureConfig()) return;

        var latest = R6ConfigService.GetLatestBackup();

        if (latest is null)
        {
            MessageBox.Show("No R6R backup exists yet. Create a backup first.", "R6R Core");
            return;
        }

        var result = MessageBox.Show(
            $"Restore the latest backup?\n\n{latest}\n\n" +
            "Core will first create a pre-restore safety copy of your current config.",
            "Confirm R6 config restore",
            MessageBoxButton.YesNo,
            MessageBoxImage.Warning);

        if (result != MessageBoxResult.Yes)
            return;

        try
        {
            var restored = R6ConfigService.RestoreLatest(_configPath!);
            ConfigActionStatusText.Text = $"Restore complete from: {restored}";

            MessageBox.Show(
                "Restore complete. A pre-restore safety backup was also created.",
                "R6R Core");
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Restore failed");
        }
    }

    private void OpenBackupFolder_Click(object sender, RoutedEventArgs e)
    {
        Directory.CreateDirectory(R6ConfigService.BackupRoot);

        Process.Start(new ProcessStartInfo
        {
            FileName = R6ConfigService.BackupRoot,
            UseShellExecute = true
        });
    }

    private void BuildOptimizationPreview_Click(object sender, RoutedEventArgs e)
    {
        if (!EnsureConfig()) return;

        try
        {
            _optimizationPlan = R6ConfigService.BuildSafeOptimizationPlan(_configPath!);
            OptimizationGrid.ItemsSource = null;
            OptimizationGrid.ItemsSource = _optimizationPlan;

            OptimizerStatusText.Text = _optimizationPlan.Count == 0
                ? "Preview complete // 0 verified safe changes are needed. Nothing will be written."
                : $"Preview complete // {_optimizationPlan.Count} verified safe change(s). Review every row before applying.";

            SetOverviewOptimizerState(_optimizationPlan.Count == 0 ? "Healthy / 0 changes" : $"{_optimizationPlan.Count} change(s)");
        }
        catch (Exception ex)
        {
            OptimizerStatusText.Text = $"Preview failed: {ex.Message}";
        }
    }

    private void ApplyOptimization_Click(object sender, RoutedEventArgs e)
    {
        if (!EnsureConfig()) return;

        if (_optimizationPlan.Count == 0)
        {
            MessageBox.Show(
                "Build a change preview first. There are currently no previewed changes to apply.",
                "R6R Core");
            return;
        }

        var summary = string.Join(
            Environment.NewLine,
            _optimizationPlan.Select(x => $"{x.Setting}: {x.Current} → {x.Proposed}"));

        var confirm = MessageBox.Show(
            $"Apply these {_optimizationPlan.Count} previewed change(s)?\n\n{summary}\n\n" +
            "Core will automatically create a rollback backup before editing the live config.",
            "Confirm R6R optimization",
            MessageBoxButton.YesNo,
            MessageBoxImage.Warning);

        if (confirm != MessageBoxResult.Yes) return;

        try
        {
            var backup = R6ConfigService.ApplySafeOptimizationPlan(_configPath!, _optimizationPlan);
            OptimizerStatusText.Text =
                $"Optimization applied and verified // rollback backup: {backup}";
            SetOverviewOptimizerState("Applied + verified");
            RefreshOverviewFromConfig();

            MessageBox.Show(
                "Optimization applied and verified. A rollback backup was created automatically.",
                "R6R Core");

            _optimizationPlan = new();
            OptimizationGrid.ItemsSource = null;
        }
        catch (Exception ex)
        {
            OptimizerStatusText.Text = $"Optimization failed safely: {ex.Message}";
            MessageBox.Show(ex.Message, "R6R optimization failed");
        }
    }

    private void RollbackOptimization_Click(object sender, RoutedEventArgs e)
    {
        if (!EnsureConfig()) return;

        var confirm = MessageBox.Show(
            "Restore the most recent pre-optimization config?\n\n" +
            "Core will create another safety copy of the current config before rollback.",
            "Confirm optimizer rollback",
            MessageBoxButton.YesNo,
            MessageBoxImage.Warning);

        if (confirm != MessageBoxResult.Yes) return;

        try
        {
            var backup = R6ConfigService.RollbackLatestOptimization(_configPath!);
            OptimizerStatusText.Text = $"Rollback complete // restored: {backup}";
            SetOverviewOptimizerState("Rolled back");
            RefreshOverviewFromConfig();
            MessageBox.Show("Optimizer rollback complete.", "R6R Core");
        }
        catch (Exception ex)
        {
            OptimizerStatusText.Text = $"Rollback failed: {ex.Message}";
            MessageBox.Show(ex.Message, "Rollback failed");
        }
    }


    private void RefreshOverviewFromConfig()
    {
        if (string.IsNullOrWhiteSpace(_configPath) || !File.Exists(_configPath))
        {
            OverviewConfigText.Text = "Not detected";
            OverviewHealthText.Text = "-- / 100";
            return;
        }

        try
        {
            var analysis = R6ConfigService.Analyze(_configPath);
            var health = R6ConfigService.CalculateHealthScore(_configPath);
            OverviewConfigText.Text = $"{analysis.Settings.Count} settings";
            OverviewHealthText.Text = $"{health} / 100  {R6ConfigService.HealthLabel(health)}";
        }
        catch
        {
            OverviewConfigText.Text = "Needs review";
            OverviewHealthText.Text = "-- / 100";
        }
    }

    private void SetOverviewOptimizerState(string text)
    {
        try { OverviewOptimizerText.Text = text; } catch { }
    }

    private void MarkOverviewSystemScanned()
    {
        try { OverviewSystemText.Text = "Scan complete"; } catch { }
    }

}
