# R6R Core 1.1 — Customer Build

This package is the customer-distribution checkpoint built from the verified R6R Core 1.0 source.

## What changed
- Product/version metadata updated to 1.1.
- Configured for a self-contained Windows x64 single-file publish.
- Customer machine does not need the .NET SDK after publishing.
- Startup crash logs now write to `%LOCALAPPDATA%\R6R Core\Logs`.
- Existing System Scan, R6 Config, Analyzer+, Safe Optimizer, backup, verification and rollback behavior is preserved.
- No registry/service/driver tweaks and no guaranteed FPS claims.

## Build the customer EXE
On the development PC, double-click:

`BUILD_CUSTOMER_EXE.bat`

The finished executable will be:

`CUSTOMER_RELEASE\R6R Core.exe`

Do not distribute the source folder to customers. Distribute the published release after testing it on the development PC.

## Test checklist
1. Open `R6R Core.exe`.
2. Run System Scan.
3. Confirm GameSettings.ini detection.
4. Run Analyzer+.
5. Build Safe Optimizer preview.
6. Confirm no changes are written without explicit confirmation.
7. Confirm backup/rollback controls still work.
8. Close and reopen the EXE.

R6R Core 1.1 remains intentionally conservative.
