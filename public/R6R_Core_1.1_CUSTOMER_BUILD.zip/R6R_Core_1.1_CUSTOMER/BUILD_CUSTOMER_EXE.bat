@echo off
setlocal
cd /d "%~dp0"

echo.
echo ==========================================
echo   R6R CORE 1.1 - CUSTOMER EXE PUBLISHER
echo ==========================================
echo.

where dotnet >nul 2>nul
if errorlevel 1 (
  echo ERROR: .NET SDK was not found on this PC.
  echo Install .NET 8 SDK on the development PC, then run this again.
  pause
  exit /b 1
)

echo Cleaning old release...
if exist "CUSTOMER_RELEASE" rmdir /s /q "CUSTOMER_RELEASE"

echo Publishing self-contained Windows x64 single-file EXE...
dotnet publish "R6R.Core.csproj" -c Release -r win-x64 --self-contained true -o "CUSTOMER_RELEASE"

if errorlevel 1 (
  echo.
  echo BUILD FAILED. Copy the error output and send it to ChatGPT.
  pause
  exit /b 1
)

echo.
echo ==========================================
echo   SUCCESS
echo ==========================================
echo Customer build:
echo %CD%\CUSTOMER_RELEASE\R6R Core.exe
echo.
echo The customer PC does NOT need the .NET SDK.
echo.
explorer "CUSTOMER_RELEASE"
pause
