$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$release = Join-Path $PSScriptRoot "CUSTOMER_RELEASE"

if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw ".NET SDK was not found on this development PC."
}

if (Test-Path $release) {
    Remove-Item $release -Recurse -Force
}

dotnet publish ".\R6R.Core.csproj" -c Release -r win-x64 --self-contained true -o $release

$exe = Join-Path $release "R6R Core.exe"
if (-not (Test-Path $exe)) {
    throw "Publish completed without the expected R6R Core.exe."
}

Write-Host ""
Write-Host "R6R Core 1.1 customer EXE created:"
Write-Host $exe
Start-Process explorer.exe $release
